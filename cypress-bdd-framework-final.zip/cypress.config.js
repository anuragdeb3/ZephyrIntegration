const env = require('./environment');
module.exports = {
  e2e: {
    baseUrl: env.baseUrl,
    supportFile: 'cypress/support/e2e.js',
    setupNodeEvents(on, config) {
      return config;
    },
  },
};