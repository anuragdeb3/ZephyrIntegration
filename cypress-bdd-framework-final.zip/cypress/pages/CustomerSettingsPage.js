class CustomerSettingsPage {
  elements = {
    financialTransferOption: (option) => cy.get(`[name="financialTransfers"][value="${option}"]`),
    currencyCheckbox: (currency) => cy.get(`[name="${currency.toLowerCase()}"]`),
    bicInput: () => cy.get('[name="bic"]'),
    accountInput: () => cy.get('[name="account"]'),
    sortCodeInput: () => cy.get('[name="sortCode"]'),
    saveButton: () => cy.contains('Save progress'),
    errorMessages: () => cy.get('.error-message'),
  };

  selectFinancialTransfer(option) {
    this.elements.financialTransferOption(option).check({ force: true });
  }

  selectCurrency(currency) {
    this.elements.currencyCheckbox(currency).check({ force: true });
  }

  enterBIC(bic) {
    this.elements.bicInput().clear().type(bic);
  }

  enterAccountNumber(account) {
    this.elements.accountInput().clear().type(account);
  }

  enterSortCode(code) {
    this.elements.sortCodeInput().clear().type(code);
  }

  saveProgress() {
    this.elements.saveButton().click();
  }

  checkForValidationErrors() {
    this.elements.errorMessages().should('exist');
  }
}

module.exports = new CustomerSettingsPage();
