Cypress.Commands.add("launchApp", () => {
  cy.visit('/');
});