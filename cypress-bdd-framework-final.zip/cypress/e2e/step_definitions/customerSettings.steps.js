const customerSettings = require('../../pages/CustomerSettingsPage');

Given('I visit the customer settings page', () => {
  cy.visit('/customer-settings');
});

When('I select financial transfer as {string}', (option) => {
  customerSettings.selectFinancialTransfer(option);
});

When('I select currency {string}', (currency) => {
  customerSettings.selectCurrency(currency);
});

When('I enter BIC {string}', (bic) => {
  customerSettings.enterBIC(bic);
});

When('I enter Settlement Account {string}', (account) => {
  customerSettings.enterAccountNumber(account);
});

When('I enter Sort Code {string}', (sortcode) => {
  customerSettings.enterSortCode(sortcode);
});

Then('I save the progress', () => {
  customerSettings.saveProgress();
});

Then('I should see validation errors', () => {
  customerSettings.checkForValidationErrors();
});
