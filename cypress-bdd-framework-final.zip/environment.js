module.exports = {
  baseUrl: "https://your-bankingapp.com",
  timeout: 10000
};