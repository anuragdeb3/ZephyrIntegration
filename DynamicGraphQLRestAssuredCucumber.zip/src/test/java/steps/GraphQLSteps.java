package steps;

import graphql.*;
import io.cucumber.java.en.*;
import io.cucumber.datatable.DataTable;
import io.restassured.response.Response;
import java.util.*;

public class GraphQLSteps {
    private String mutationName;
    private String query;
    private String variables;
    private Response response;

    @Given("I prepare a GraphQL mutation {string}")
    public void iPrepareGraphQLMutation(String mutation) {
        this.mutationName = mutation;
    }

    @And("I add the following sections and fields:")
    public void iAddTheFollowingSections(DataTable table) {
        List<String> sections = new ArrayList<>();
        for (Map<String, String> row : table.asMaps()) {
            sections.add(row.get("section"));
        }
        query = GraphQLQueryBuilder.buildMutation(mutationName, sections);
    }

    @And("I prepare GraphQL variables dynamically:")
    public void iPrepareGraphQLVariables(DataTable table) {
        VariableBuilder vb = new VariableBuilder();
        table.asMaps().forEach(row -> vb.setValue(row.get("path"), row.get("value")));
        variables = vb.build();
    }

    @When("I execute the GraphQL mutation")
    public void iExecuteTheGraphQLMutation() {
        response = GraphQLClient.sendQuery("https://api.yourgraphqlendpoint.com/graphql", query, variables);
        response.then().log().all();
    }

    @Then("the response status should be {int}")
    public void verifyStatus(int status) {
        response.then().statusCode(status);
    }

    @Then("the {string} field should be true")
    public void verifyFieldTrue(String field) {
        response.then().body(field, org.hamcrest.Matchers.equalTo(true));
    }
}
