package graphql;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.*;

import java.util.Arrays;

public class VariableBuilder {

    private final ObjectMapper mapper = new ObjectMapper();
    private final ObjectNode root = mapper.createObjectNode();

    public void setValue(String path, String value) {
        setNestedValue(root, path.split("\\."), value);
    }

    private void setNestedValue(ObjectNode node, String[] path, String value) {
        String current = path[0];
        if (path.length == 1) {
            node.put(current, value);
            return;
        }
        ObjectNode next = (ObjectNode) node.get(current);
        if (next == null) {
            next = mapper.createObjectNode();
            node.set(current, next);
        }
        setNestedValue(next, Arrays.copyOfRange(path, 1, path.length), value);
    }

    public String build() {
        ObjectNode request = mapper.createObjectNode();
        request.set("request", root);
        try {
            return mapper.writeValueAsString(request);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
