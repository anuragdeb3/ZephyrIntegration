package graphql;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;

public class GraphQLClient {
    public static Response sendQuery(String baseUrl, String query, String variables) {
        return given()
                .contentType(ContentType.JSON)
                .body("{\"query\":\""+query.replace("\"", "\\\"")+"\",\"variables\":"+variables+"}")
                .when()
                .post(baseUrl);
    }
}
