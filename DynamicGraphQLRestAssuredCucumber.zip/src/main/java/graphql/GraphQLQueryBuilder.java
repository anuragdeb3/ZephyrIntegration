package graphql;

import java.util.*;

public class GraphQLQueryBuilder {

    public static String buildMutation(String mutationName, List<String> sections) {
        StringBuilder sb = new StringBuilder();
        sb.append("mutation ").append(mutationName).append("($request: CreateAccountDataInput!) {");
        sb.append(" createAccountData(request: $request) { success message result { ");
        for (String section : sections) {
            sb.append(section).append(" ");
        }
        sb.append("} } }");
        return sb.toString();
    }
}
